
name := "HoCSparkScala"
version := "0.1"
scalaVersion := "2.12.18"
val sparkVersion = "3.5.0"
libraryDependencies ++=Seq (
  "org.apache.spark" %% "spark-core" % sparkVersion,
  "org.apache.spark" %% "spark-sql" % sparkVersion
)

fork := true

javaOptions ++= Seq(
  "--add-exports=java.base/sun.nio.ch=ALL-UNNAMED",
  "--add-opens=java.base/java.nio=ALL-UNNAMED"
)
