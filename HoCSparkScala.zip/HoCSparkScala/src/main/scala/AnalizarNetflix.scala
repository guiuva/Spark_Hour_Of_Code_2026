import utils.DataLoader._
import utils.SparkFactory._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

/**
 * Netflix quiere construir un dataset analítico para ayudar a su equipo de negocio a identificar:
 * Las películas más populares.
 * Las películas mejor valoradas.
 * Las mejores películas por década.
 * Qué décadas han tenido mejor aceptación entre los usuarios.
 *
 * Movie_ID
 * Name
 * Year
 * Decade
 * NumRatings
 * AvgRating
 * PopularitySegment
 * RatingCategory
 * y guardarlo como
 *
 * data/netflix_movie_analytics
 */

object AnalizarNetflix {

  def main(args: Array[String]): Unit = {

    //Ejercicio 1. Exploración de datos (número de filas, esquema)

    println(s"Número de películas:")
    println(s"Número de ratings: ")

    //Esquemas
    movies.printSchema()
    ratings.printSchema()

    //Eliminación de nulls

    //Había algún null?
    println(s"Películas limpias:")
    println(s"Ratings limpios:")

    //Ejercicio 2. Media de las peliculas

    //Ejercicio 3. ¿Cuál es la pelicula con peor nota?

    //Ejercicio 4. Popularidad de las peliculas

    //Ejercicio 5. Unificar las métricas

    //Ejercicio 6. ¿Cuántas películas hay por año?

    //Ejercicio 7. Crear década

    //Ejercicio 8. Clasificar las películas en función de cuantos ratings tenga.
    // + de 10000, + de 5000, resto

    //Ejercicio 9. ¿Cuáles son los usuarios más activos?

    //Ejercicio 10. Ranking global y ranking por década



    movies.printSchema()
    ratings.printSchema()
  }



}
