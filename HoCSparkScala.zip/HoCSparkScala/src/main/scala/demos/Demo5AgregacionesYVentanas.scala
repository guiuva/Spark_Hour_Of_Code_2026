package demos
import utils.SparkFactory._
import utils.DataLoader._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

object Demo5AgregacionesYVentanas {

  def main(args: Array[String]): Unit = {

    //Cuantos ratings hay?

    val movieStats = ratings
        .groupBy("Movie_ID")
        .agg(
          count("*").as("numRatings"),
          avg("Rating").as("avgRating")
        )

    movieStats.show(20)

    val popularityWindow = Window
      .partitionBy("numRatings")
      .orderBy(col("avgRating").desc)

    val moviesRanking = movieStats
      .withColumn("ranking",
        row_number().over(popularityWindow)
      )

    moviesRanking.show()
  }

}
