package demos

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.DataLoader._
import utils.SparkFactory._
import spark.implicits._



object Demo3TransformacionesSencillas {

  def main(args: Array[String]): Unit = {

    //vamos a quedarnos con el id y el nombre de aquellas películas que son
    //del 2000, y vamos a ordenarlo de forma descendente

  }

}
