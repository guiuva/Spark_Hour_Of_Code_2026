package demos

import utils.DataLoader._
import utils.SparkFactory.spark

object Demo6Joins {

  def main(args: Array[String]): Unit = {

    ratings.join(movies,
        Seq("Movie_ID"))
      .select("Movie_ID","Name","Rating")
      .show(20, false)

  }

}