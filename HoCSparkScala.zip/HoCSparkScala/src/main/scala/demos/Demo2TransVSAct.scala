package demos

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.DataLoader._
import utils.SparkFactory._

object Demo2TransVSAct {

  def main(args: Array[String]): Unit = {

    //¿Esto es una transformación o una acción?
    val moderMovies = movies.filter(col("Year") >= 2000)

    moderMovies.explain()
    moderMovies.show()


  }
}