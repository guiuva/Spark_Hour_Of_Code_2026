package demos
import org.apache.spark.sql.SparkSession
import utils.DataLoader._
import utils.SparkFactory._

object Demo1Exploracion {

  def main(args: Array[String]): Unit = {


    //¿Como podemos ver su esquema?

    //¿Como mostramos el DF?

    //¿Cuántas filas tiene?

    //¿estadisticas generales?


  }

}
