package demos

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.DataLoader._
import utils.SparkFactory._

object Demo4CrearYEditarColumnas {

  def main(args: Array[String]): Unit = {

    //¿Cuántos años tiene cada peli?

  }

}
