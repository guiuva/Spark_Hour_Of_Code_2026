package utils

import org.apache.spark.sql.SparkSession

object SparkFactory {

  lazy val spark: SparkSession =
    SparkSession.builder()
      .appName("HoCSpark")
      .master("local[*]")
      .getOrCreate()

}