package utils

import org.apache.spark.sql.DataFrame

object DataLoader {

  def movies: DataFrame =
    SparkFactory.spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv("data/Netflix_Dataset_Movie.csv")

  def ratings: DataFrame =
    SparkFactory.spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv("data/Netflix_Dataset_Rating.csv")

}